#ifndef NETH
#define NETH

int create_service(short port);
int accept_connection(int fd);

#endif

